package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import dto.UserDto;

public class UserDao 
{
	public Connection establishConnection() throws Exception
	{
		Class.forName("com.mysql.cj.jdbc.Driver");
		String url = "jdbc:mysql://localhost:3307/bank_project?createDatabaseIfNotExist=true";
		String user = "root";
		String password = "root";

		Connection con = DriverManager.getConnection(url, user, password);
		return con;
	}
	
	public  void createTable() throws Exception
	{
		Connection con =  establishConnection();
		Statement s = con.createStatement();
		s.execute("CREATE TABLE IF NOT EXISTS user (FName VARCHAR(45) , LName VARCHAR(45), Phone BIGINT(10) UNIQUE, Gender VARCHAR(10),DOB VARCHAR(20), Email VARCHAR(45) PRIMARY KEY, Pwd VARCHAR(45),Address VARCHAR(45));");
	}
	
	public int saveUser(UserDto udto) throws Exception
	{
		try {
			Connection con = establishConnection();
			
			PreparedStatement ps = con.prepareStatement("INSERT INTO user(FNAME,LNAME,PHONE,GENDER,DOB,EMAIl,PWD,ADDRESS) VALUES(?,?,?,?,?,?,?,?)");
			
			ps.setString(1, udto.getFirstName());
			ps.setString(2, udto.getLastName());
			
			ps.setLong(3, udto.getPhone());
			
			ps.setString(4, udto.getGender());
			
			ps.setString(5, udto.getDateOfBirth());
			
			ps.setString(6, udto.getEmail());
			
			ps.setString(7, udto.getPassword());
			ps.setString(8, udto.getAddress());
			
			return ps.executeUpdate();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		return 0;
		
	}
	public boolean fetchUser(String email,String pwd)
	{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3307/bank_project","root","root");
			PreparedStatement ps = con.prepareStatement("select * from user where email=? and pwd=?");
			ps.setString(1, email);
			ps.setString(2, pwd);
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
//				System.out.println(rs.getString("email")+" "+rs.getString("pwd"));
				if(rs.getString("email").equals(email) && rs.getString("pwd").equals(pwd))
				{
					return true;
				}
			}			
		} catch (SQLException | ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
		return false;
		
	}

	public int deleteUser(String email, String pwd) throws Exception 
	{
		try {
			Connection con =  establishConnection();
			PreparedStatement ps = con.prepareStatement("DELETE FROM USER WHERE EMAIL=? AND pwd=?");
			ps.setString(1, email);
			ps.setString(2, pwd);
			return ps.executeUpdate();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		return 0;
	}

}
