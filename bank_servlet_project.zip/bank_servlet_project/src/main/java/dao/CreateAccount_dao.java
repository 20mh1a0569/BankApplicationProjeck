package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import dto.CreateAccount_dto;

public class CreateAccount_dao
{
	public void createTable() throws Exception
	{
		Connection con=createConnection();
		Statement s=con.createStatement();
		s.execute("Create TABLE IF NOT EXISTS bankaccount (Firstname VARCHAR(45),Lastname VARCHAR(45),Aadhaarnumber BIGINT,Accountnumber BIGINT UNIQUE,IFSCCode VARCHAR(11),Accounttype VARCHAR(45),Mobilenumber BIGINT PRIMARY KEY,Address VARCHAR(45),Balance DECIMAL)");

	}

	public Connection createConnection() throws Exception
	{
		Class.forName("com.mysql.cj.jdbc.Driver");
		return DriverManager.getConnection("jdbc:mysql://localhost:3307/bank_project?createDatabaseIfNotExist=true","root","root");
	}
	public int createUser(CreateAccount_dto account) throws Exception
	{
		Connection con=createConnection();
		createTable();
		PreparedStatement ps=con.prepareStatement("insert into bankaccount values(?,?,?,?,?,?,?,?,?)");
		ps.setString(1, account.getFirstname());
		ps.setString(2, account.getLastname());
		ps.setLong(3, account.getAadhaarnumber());
		ps.setLong(4, account.getAccountnumber());
		ps.setString(5, account.getIFSCCode());
		ps.setString(6, account.getAccounttype());
		ps.setLong(7, account.getMobilenumber());
		ps.setString(8, account.getAddress());
		ps.setFloat(9, account.getBalance());
		return ps.executeUpdate();
	}
	public CreateAccount_dto getBankDetails(long mobile) throws Exception
	{
		boolean isFound = false;
			Connection con=createConnection();
			PreparedStatement ps=con.prepareStatement("select * from bankaccount where Mobilenumber=?");
			ps.setLong(1, mobile);
			ResultSet rs=ps.executeQuery();
			CreateAccount_dto bank= new CreateAccount_dto();
			while(rs.next())
			{
				bank=new CreateAccount_dto(rs.getLong("Accountnumber"), rs.getLong("Mobilenumber"), rs.getString("Accounttype"), rs.getString("Address"), rs.getLong("Aadhaarnumber"), rs.getFloat("Balance"), rs.getString("IFSCCode"));	
				isFound=true;
			}
			ps.close();
			con.close();
		if(isFound)
		{
			return bank;
		}
		else return null;
		
	}


}

