package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import dto.BankTransactionDto;

public class BankTransactionDao {

    // Establish connection to the database
    public Connection establishConnection() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        String url = "jdbc:mysql://localhost:3307/bank_project?createDatabaseIfNotExist=true";
        String user = "root";
        String password = "root";
        return DriverManager.getConnection(url, user, password);
    }

    // Retrieve data for a given account number
    public long retrieveData(BankTransactionDto btdto) throws Exception {
        String query = "SELECT Accountnumber FROM bankaccount WHERE Accountnumber = ?";
        try (Connection con = establishConnection();
             PreparedStatement ps = con.prepareStatement(query)) {

            ps.setLong(1, btdto.getSourceAccNo());
            try (ResultSet res = ps.executeQuery()) {
                if (res.next()) {
                    return res.getLong("Accountnumber");
                }
            }
        } catch (Exception e) {
            System.err.println("Error retrieving data: " + e.getMessage());
            throw e;
        }
        return 0;
    }

    // Get the amount for a specific account number
    public float amount(BankTransactionDto btdto) throws Exception {
        String query = "SELECT balance FROM bankaccount WHERE Accountnumber = ?";
        try (Connection con = establishConnection();
             PreparedStatement ps = con.prepareStatement(query)) {

            ps.setLong(1, btdto.getSourceAccNo());
            try (ResultSet res = ps.executeQuery()) {
                if (res.next()) {
                    return res.getFloat("balance");
                }
            }
        } catch (Exception e) {
            System.err.println("Error fetching amount: " + e.getMessage());
            throw e;
        }
        return 0;
    }

    // Update balance for a specific account
    public int updateAmount(float balance, long accountNumber) throws Exception {
        String query = "UPDATE bankaccount SET balance = ? WHERE Accountnumber = ?";
        try (Connection con = establishConnection();
             PreparedStatement ps = con.prepareStatement(query)) {

            ps.setFloat(1, balance);
            ps.setLong(2, accountNumber);
            return ps.executeUpdate();
        } catch (Exception e) {
            System.err.println("Error updating amount: " + e.getMessage());
            throw e;
        }
    }

    // Retrieve the balance for a given account number and IFSC code
    public float getAmountFromSource(long sourceAccNo, String sourceIFSCNo) throws Exception {
        String query = "SELECT balance FROM bankaccount WHERE AccountNumber = ? AND IFSCCode = ?";
        try (Connection con = establishConnection();
             PreparedStatement ps = con.prepareStatement(query)) {

            ps.setLong(1, sourceAccNo);
            ps.setString(2, sourceIFSCNo);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getFloat("balance");
                }
            }
        } catch (Exception e) {
            System.err.println("Error retrieving amount from source: " + e.getMessage());
            throw e;
        }
        return 0;
    }

    // Update the balance for a destination account number and IFSC code
    public int updateAmountDest(float destCurrentAmount, long destinationAccNo, String destinationIFSCNo) throws Exception {
        String query = "UPDATE bankaccount SET Balance = ? WHERE AccountNumber = ? AND IFSCCode = ?";
        try (Connection con = establishConnection();
             PreparedStatement ps = con.prepareStatement(query)) {
        	System.out.println(destCurrentAmount+" "+destinationAccNo+" "+destinationIFSCNo);

            ps.setFloat(1, destCurrentAmount);
            ps.setLong(2, destinationAccNo);
            ps.setString(3, destinationIFSCNo);
            return ps.executeUpdate();
        } catch (Exception e) {
            System.err.println("Error updating destination amount: " + e.getMessage());
            throw e;
        }
    }
}

//package dao;
//
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//
//import dto.BankTransactionDto;
//
//public class BankTransactionDao 
//{
//	
//	public Connection establishConnection() throws Exception
//	{
//		Class.forName("com.mysql.cj.jdbc.Driver");
//		
//		
//		String url = "jdbc:mysql://localhost:3307/bank_project?createDatabaseIfNotExist=true";
//		String user = "root";
//		String password = "root";
//		Connection con = DriverManager.getConnection(url, user, password);
//		
//		return con;
//	}
//	
//	public long retriveData(BankTransactionDto btdto) throws Exception
//	{
//		Connection con = establishConnection();
//		
//		PreparedStatement ps = con.prepareStatement("SELECT * FROM bankaccount WHERE Accountnumber=?");
//		ps.setLong(1, btdto.getSourceAccNo());
//		ResultSet res = ps.executeQuery();
//		if(res.next())
//		{
//			return btdto.getSourceAccNo();
//		}
//		return 0;
//	}
//	
//	public float amount(BankTransactionDto btdto) throws Exception
//	{
//		Connection con = establishConnection();
//		PreparedStatement ps = con.prepareStatement("SELECT * FROM bankaccount WHERE Accountnumber=?");
//		ps.setLong(1, btdto.getSourceAccNo());
//		ResultSet res = ps.executeQuery();
//		if(res.next())
//		{
//			return btdto.getAmount();
//		}
//		return 0;
//	}
//	
//	public int updateAmount(float balance,long accountnumber) throws Exception {
//        Connection con = establishConnection();
//        PreparedStatement ps = con.prepareStatement("UPDATE bankaccount SET balance = ? WHERE Accountnumber = ?");
//        ps.setFloat(1, balance);
//        ps.setLong(2, accountnumber);
//        return ps.executeUpdate();
//    }
//
//	public float getAmountFromSource(long sourceAccNo,String sourceIFSCNo) throws Exception 
//	{
//		try
//		{
//			Connection con = establishConnection();
//			PreparedStatement ps = con.prepareStatement("SELECT * FROM bankaccount where AccountNumber=? and IFSCCode=?");
//			ps.setLong(1, sourceAccNo);
//			ps.setString(2, sourceIFSCNo);
//			ResultSet rs=ps.executeQuery();
//			while(rs.next())
//			{
//				if(rs.getLong("Accountnumber")==sourceAccNo)
//				{
//					return rs.getFloat("balance");
//				}
////				System.out.println(rs.getLong("Accountnumber")+" "+rs.getFloat("balance"));
//			}
//		}
//		catch(Exception e)
//		{
//			System.out.println(e.getMessage());
//		}
//		
//		return 0;	
//	}
//
//	public int updateAmountDest(float destcurrentAmount, long destinationAccNo, String destinationIFSCNo) throws Exception
//	{
//		try {
//			Connection con = establishConnection();
//			PreparedStatement ps = con.prepareStatement("Update bankaccount set Balance=? where AccountNumber=? and IFSCCode=?");
//			ps.setFloat(1, destcurrentAmount);
//			ps.setLong(2, destinationAccNo);
//			ps.setString(3, destinationIFSCNo);
//			return ps.executeUpdate();
//		}
//		catch(Exception e)
//		{
//			System.out.println(e.getMessage());
//		}
//		return 0;
//		
//	}
//
//
//	
//			
//
//}
//
