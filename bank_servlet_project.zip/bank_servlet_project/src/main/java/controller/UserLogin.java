package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.UserDao;
@WebServlet("/login")
public class UserLogin extends HttpServlet
{
	static UserDao udao=new UserDao();
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String email=req.getParameter("email");
		String pwd = req.getParameter("pwd");
		boolean res=udao.fetchUser(email,pwd);
//		PrintWriter pw = resp.getWriter();
		if(res)
		{
			RequestDispatcher dispatcher = req.getRequestDispatcher("HomePage.jsp");
			dispatcher.forward(req, resp);

		}
		else
		{
			// If login fails, set an error message and redirect back to login page
            req.setAttribute("errorMessage", "Invalid Email or Password");
            RequestDispatcher dispatcher = req.getRequestDispatcher("index.jsp"); // Change to your login page if needed
            dispatcher.forward(req, resp);
		}
				
	}

}
