package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dto.UserDto;

@WebServlet("/signup")
public class Update_login extends HttpServlet{
	// TODO Auto-generated method stub
			
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String email=req.getParameter("email");
		String password=req.getParameter("password");
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3307/bank_project", "root", "root");
			PreparedStatement ps=c.prepareStatement("select * from user where email=?");
			ps.setString(1, email);
	     	ResultSet res=ps.executeQuery();
		    if(res.next())
			{
		    	if(res.getString(7).equals(password))
		    	{
		    		String fname=res.getString(1);
					String lname=res.getString(2);
					long ph=res.getLong(3);
					String gender=res.getString(4);
					String dob=res.getString(5);
					String email1=res.getString(6);
					String pwd1=res.getString(7);
					String add=res.getString(8);
					UserDto ud=new UserDto(fname, lname,ph,gender,dob,email1, pwd1,add);
					req.getSession().setAttribute("user", ud);
					RequestDispatcher dispatcher=req.getRequestDispatcher("profile.jsp");
					dispatcher.forward(req, resp);
				}
				else
				{
					req.setAttribute("mess", "Incorrect password");
					RequestDispatcher dispatcher=req.getRequestDispatcher("update_login.jsp");
					dispatcher.include(req, resp);
				}
			}
			else
			{
				req.setAttribute("message", "Invalid email");
				RequestDispatcher dispatcher=req.getRequestDispatcher("update_login.jsp");
				dispatcher.include(req, resp);
			}
		} 
		    	catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

