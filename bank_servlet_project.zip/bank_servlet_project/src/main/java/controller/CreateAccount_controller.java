package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.CreateAccount_dao;
import dto.CreateAccount_dto;
@WebServlet("/createaccount")
public class CreateAccount_controller extends HttpServlet
{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String Firstname=req.getParameter("Firstname");
		String Lastname=req.getParameter("Lastname");
	    long Aadhaarnumber=Long.parseLong(req.getParameter("Aadhaarnumber"));
		long Acountnumber=Long.parseLong(req.getParameter("Accountnumber"));
		String IFSCCode=req.getParameter("IFSCCode");
		String Accountype=req.getParameter("Accounttype");
		long Mobilenumber=Long.parseLong(req.getParameter("Mobilenumber"));
		String Address=req.getParameter("Address");
		float Balance=Float.parseFloat(req.getParameter("Balance"));
		HttpSession session=req.getSession();

		CreateAccount_dao dao=new CreateAccount_dao();
		try {
			int result=dao.createUser(new CreateAccount_dto(Firstname,Lastname,Accountype,Address,IFSCCode, Aadhaarnumber,Acountnumber,Mobilenumber,Balance));
			if(result>0)
			{
//				req.setAttribute("success","Account Created Suucessfully successfully");
//				RequestDispatcher dispatcher=req.getRequestDispatcher("CreateAccount.jsp");
//				dispatcher.include(req, resp);
				CreateAccount_dto bc = dao.getBankDetails(Mobilenumber);
				System.out.println(bc.toString());
//				session.setAttribute("bank",new CreateAccount_dto(Acountnumber,Mobilenumber,Accountype,Address,Aadhaarnumber,Balance,IFSCCode));
				session.setAttribute("bank", bc);
			}
//			else
//			{
//				req.setAttribute("fail","Account is not Created.Account is Alraedy Existed");
//				RequestDispatcher dispatcher=req.getRequestDispatcher("CreateAccount.jsp");
//				dispatcher.include(req, resp);
//			}
			session.setAttribute("status","created");
			Thread.sleep(4000);
			RequestDispatcher d=req.getRequestDispatcher("HomePage.jsp");
			d.forward(req, resp);

			
//			System.out.println(dao.toString());
		} catch (Exception e) 
		{
			e.printStackTrace();
			req.setAttribute("msg","account with given aadhar number already exists");
			RequestDispatcher d1=req.getRequestDispatcher("CreateAccount.jsp");
			d1.include(req, resp);

		}

		
		
	}

}

