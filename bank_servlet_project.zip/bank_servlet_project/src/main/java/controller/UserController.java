package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.UserDao;
import dto.UserDto;


@WebServlet("/Register")
public class UserController extends HttpServlet
{
	static UserDao udao=new UserDao();	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
	{
	
		
		
		String firstName = req.getParameter("firstName");
		String lastName = req.getParameter("lastName");
		long phone = Long.parseLong(req.getParameter("Phone"));
		String gender=req.getParameter("gender");
		String dateOfBirth=req.getParameter("dob");
		String email = req.getParameter("email");
		String password=req.getParameter("password");
		String address=req.getParameter("address");
		
		UserDto udto = new UserDto(firstName, lastName, phone, gender, dateOfBirth, email, password, address);
		PrintWriter pw=resp.getWriter();
		
		
		try {
			
			udao.createTable();
			int res=udao.saveUser(udto);
			if(res>0)
			{
				System.out.println("Record Stored Successfully");
//				pw.print("Record Stored Successfully");
				RequestDispatcher dispatcher = req.getRequestDispatcher("index.jsp");
				dispatcher.forward(req, resp);
			}
			else
			{
				System.out.println("Un sucessful");
				pw.print("Record not stored");
			}
		} 
		catch (Exception e) {
			
			e.printStackTrace();
		}
//		System.out.println("Data Entered Successfully");
		
		
	}

}
