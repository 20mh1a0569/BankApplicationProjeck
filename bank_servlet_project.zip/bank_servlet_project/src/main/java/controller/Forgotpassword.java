package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/reset")
public class Forgotpassword extends HttpServlet
{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		String email=req.getParameter("email");
		String password=req.getParameter("new-password");
		String confirmpassword=req.getParameter("confirm-password");
//		System.out.println(email);
//		System.out.println(password);
		resp.setContentType("text/html");
		//load and register
		try 
		{
			Driver d = new com.mysql.cj.jdbc.Driver();
			DriverManager.registerDriver(d);
			//Establish the connection 
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3307/bank_project?user=root&password=root");
			//Creation of statement
			PreparedStatement checkEmail = con.prepareStatement("select email from user where email=?");
			checkEmail.setString(1, email);
			ResultSet res = checkEmail.executeQuery();
			if (!res.next()) 
			{
				// Email not found, display error message
				req.setAttribute("mail","*Email is invalid");
				RequestDispatcher dispatcher=req.getRequestDispatcher("forgotpassword.jsp");
				dispatcher.include(req, resp);
			} 
			else 
			{
				if(password.equals(confirmpassword)) 
				{
					// Email found, update password
					PreparedStatement ps = con.prepareStatement("update user set PWD=? where email=?");
					ps.setString(1, password);
					ps.setString(2, email);
					int updatedRows = ps.executeUpdate();
					if (updatedRows > 0) 
					{
						req.setAttribute("pass","Password updated successfully");
						RequestDispatcher dispatcher=req.getRequestDispatcher("forgotpassword.jsp");
						dispatcher.include(req, resp);
					} 
					else 
					{
						resp.getWriter().println("<h3>Error updating password</h3>");
					}
					ps.close();
				}
				else
				{
					req.setAttribute("cpass","* Confirm password is not matched");
					RequestDispatcher dispatcher=req.getRequestDispatcher("forgotpassword.jsp");
					dispatcher.include(req, resp);
				}
			}
			checkEmail.close();
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
			resp.getWriter().println("<h3>Database error</h3>");
		}
	}
}

