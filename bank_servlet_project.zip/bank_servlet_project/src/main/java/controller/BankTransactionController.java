package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.BankTransactionDao;
import dto.BankTransactionDto;

@WebServlet("/Transaction")
public class BankTransactionController extends HttpServlet
{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
	{
		BankTransactionDao btdao = new BankTransactionDao();
		String holderName=req.getParameter("holderName");
		String sourceAccountId=req.getParameter("sourceAccountId");
		long sourceAccNo=Long.parseLong(sourceAccountId);
		String sourceIFSCNo=req.getParameter("sourceIfscCode");
		float amount = Float.parseFloat(req.getParameter("amount"));
		String destinationAccountId = req.getParameter("destinationAccountId");
		long destinationAccNo=Long.parseLong(destinationAccountId);
		String destinationIFSCNo = req.getParameter("destinationIfscCode");

		BankTransactionDto btdto= new BankTransactionDto(sourceAccNo, sourceIFSCNo, destinationAccNo, destinationIFSCNo, amount);
		btdto.toString();
		try 
		{
			float currentAmount = btdao.getAmountFromSource(sourceAccNo,sourceIFSCNo);

			float destcurrentAmount = btdao.getAmountFromSource(destinationAccNo, destinationIFSCNo);

			if (currentAmount >= amount) {
				//	        	btdao.transaction(btdto);
				float updatedAmount = currentAmount - amount; 
				System.out.println(updatedAmount);
				float updateDestAmount = destcurrentAmount + amount;
				System.out.println(updateDestAmount);

				int res=btdao.updateAmount(updatedAmount,sourceAccNo);

				int result=btdao.updateAmountDest(updateDestAmount, destinationAccNo, destinationIFSCNo);

				System.out.println(result+" Result");
				RequestDispatcher dispatcher = req.getRequestDispatcher("transactionsuccess.jsp");
				dispatcher.forward(req, resp);
//				resp.getWriter().println("Transaction Successful. Remaining balance: " + updatedAmount);
			} 
			else 
			{
				resp.getWriter().println("Insufficient balance.");
			}
		} 

		catch (Exception e) 
		{

			e.printStackTrace();
		}

	}


}

