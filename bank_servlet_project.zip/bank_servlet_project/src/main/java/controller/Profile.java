package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/update")
public class Profile extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // This is the password from the form
    	 String fname = req.getParameter("fname");
         String lname = req.getParameter("lname");
         String gender = req.getParameter("gender");
         String dob = req.getParameter("dob");
         String phone = req.getParameter("phone");
         String address = req.getParameter("address");
         String email = req.getParameter("email");
         String password = req.getParameter("password");
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3307/bank_project", "root", "root");

            PreparedStatement ps = conn.prepareStatement("SELECT * FROM user WHERE email = ?");
            ps.setString(1, email);
            ResultSet res = ps.executeQuery();

            if (res.next()) 
            {
                // Compare the password input from the form with the password in the database
                if (res.getString(7).equals(password)) {
                    PreparedStatement updatePs = conn.prepareStatement(
                            "UPDATE user SET fname = ?, lname = ?, gender = ?, dob = ?, phone = ?, address = ? WHERE email = ?");
                    updatePs.setString(1, fname);
                    updatePs.setString(2, lname);
                    updatePs.setString(3, gender);
                    updatePs.setString(4, dob);
                    updatePs.setString(5, phone);
                    updatePs.setString(6, address);
                    updatePs.setString(7, email); // Ensure email is set correctly

                    int updatedRows = updatePs.executeUpdate();
                    if (updatedRows > 0) 
                    {
                        setUserAttributes(req, email, conn);
                        req.setAttribute("mess1", "User information updated successfully!");
                    } 
                    else 
                    {
                        req.setAttribute("mess2", "Error: User information could not be updated.");
                    }
                } 
                else 
                {
                    req.setAttribute("mess", "Invalid password");
                }
            } else {
                req.setAttribute("message", "Invalid email");
            }

            forwardRequest(req, resp, "profile.jsp");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            req.setAttribute("message", "Database error occurred. Please try again.");
            forwardRequest(req, resp, "profile.jsp");
        }
    }
    private void setUserAttributes(HttpServletRequest req, String email, Connection conn) throws SQLException {
        PreparedStatement ps = conn.prepareStatement("SELECT * FROM user WHERE email = ?");
        ps.setString(1, email);
        ResultSet res = ps.executeQuery();

        if (res.next()) {
            req.setAttribute("e", res.getString("email"));
            req.setAttribute("fn", res.getString("fname"));
            req.setAttribute("ln", res.getString("lname"));
            req.setAttribute("g", res.getString("gender"));
            req.setAttribute("dob", res.getString("dob"));
            req.setAttribute("phnum1", res.getString("phone"));
            req.setAttribute("add", res.getString("address"));
            req.setAttribute("pwd", res.getString("pwd"));
        }
    }

    private void forwardRequest(HttpServletRequest req, HttpServletResponse resp, String page)
            throws ServletException, IOException 
    {
        RequestDispatcher dispatcher = req.getRequestDispatcher(page);
        dispatcher.forward(req, resp);
    }

   
}

