package dto;

public class BankTransactionDto 
{
	private long sourceAccNo;
	private String sourceIFSCNo;
	private long destinationAccNo;
	private String destinationIFSCNo;
	private float amount;
	
	
	
//	public BankTransactionDto() {
//		super();
//		
//	}
	
	public BankTransactionDto(long sourceAccNo, String sourceIFSCNo, long destinationAccNo,
			String destinationIFSCNo, float amount) {
		super();
		this.sourceAccNo = sourceAccNo;
		this.sourceIFSCNo = sourceIFSCNo;
		this.destinationAccNo = destinationAccNo;
		this.destinationIFSCNo = destinationIFSCNo;
		this.amount = amount;
	}
	
	
	public long getSourceAccNo() {
		return sourceAccNo;
	}
	public void setSourceAccNo(long sourceAccNo) {
		this.sourceAccNo = sourceAccNo;
	}
	public String getSourceIFSCNo() {
		return sourceIFSCNo;
	}
	public void setSourceIFSCNo(String sourceIFSCNo) {
		this.sourceIFSCNo = sourceIFSCNo;
	}
	
	public long getDestinationAccNo() {
		return destinationAccNo;
	}
	public void setDestinationAccNo(long destinationAccNo) {
		this.destinationAccNo = destinationAccNo;
	}
	public String getDestinationIFSCNo() {
		return destinationIFSCNo;
	}
	public void setDestinationIFSCNo(String destinationIFSCNo) {
		this.destinationIFSCNo = destinationIFSCNo;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	
	@Override
	public String toString() {
		return "BankTransactionDto [sourceAccNo=" + sourceAccNo + ", sourceIFSCNo=" + sourceIFSCNo 
				+ ", destinationAccNo=" + destinationAccNo + ", destinationIFSCNo=" + destinationIFSCNo
				+ ", amount=" + amount + "]";
	}
	

}

