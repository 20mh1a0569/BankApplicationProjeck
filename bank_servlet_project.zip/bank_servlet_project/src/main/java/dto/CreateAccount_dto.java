package dto;

public class CreateAccount_dto {
	private String Firstname,Lastname,Accounttype,Address,IFSCCode;
	private Long Aadhaarnumber,Accountnumber,Mobilenumber;
	private Float Balance;	
	public CreateAccount_dto(String firstname, String lastname, String accounttype, String address, String iFSCCode,
		Long aadhaarnumber, Long accountnumber, Long mobilenumber, Float balance) {
	super();
	Firstname = firstname;
	Lastname = lastname;
	Accounttype = accounttype;
	Address = address;
	IFSCCode = iFSCCode;
	Aadhaarnumber = aadhaarnumber;
	Accountnumber = accountnumber;
	Mobilenumber = mobilenumber;
	Balance = balance;
}

	public CreateAccount_dto(Long accountnumber,Long mobilenumber,String accounttype, String address,Long aadhaarnumber,Float balance,String iFSCCode) {
		super();
		Accounttype = accounttype;
		Address = address;
		IFSCCode = iFSCCode;
		Aadhaarnumber = aadhaarnumber;
		Accountnumber = accountnumber;
		Mobilenumber = mobilenumber;
		Balance = balance;
	}




	public CreateAccount_dto() {
		// TODO Auto-generated constructor stub
	}




	public String getFirstname() {
		return Firstname;
	}
	public void setFirstname(String firstname) {
		Firstname = firstname;
	}
	public String getLastname() {
		return Lastname;
	}
	public void setLastname(String lastname) {
		Lastname = lastname;
	}
	public String getAccounttype() {
		return Accounttype;
	}
	public void setAccounttype(String accounttype) {
		Accounttype = accounttype;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getIFSCCode() {
		return IFSCCode;
	}
	public void setIFSCCode(String iFSCCode) {
		IFSCCode = iFSCCode;
	}
	public Long getAadhaarnumber() {
		return Aadhaarnumber;
	}
	public void setAadhaarnumber(Long aadhaarnumber) {
		Aadhaarnumber = aadhaarnumber;
	}
	public Long getAccountnumber() {
		return Accountnumber;
	}
	public void setAccountnumber(Long accountnumber) {
		Accountnumber = accountnumber;
	}
	public Long getMobilenumber() {
		return Mobilenumber;
	}
	public void setMobilenumber(Long mobilenumber) {
		Mobilenumber = mobilenumber;
	}
	public Float getBalance() {
		return Balance;
	}
	public void setBalance(Float balance) {
		Balance = balance;
	}
	@Override
	public String toString() {
		return "CreateAccount_dto [Firstname=" + Firstname + ", Lastname=" + Lastname + ", Accounttype=" + Accounttype
				+ ", Address=" + Address + ", IFSCCode=" + IFSCCode + ", Aadhaarnumber=" + Aadhaarnumber
				+ ", Accountnumber=" + Accountnumber + ", Mobilenumber=" + Mobilenumber + ", Balance=" + Balance + "]";
	}
}
